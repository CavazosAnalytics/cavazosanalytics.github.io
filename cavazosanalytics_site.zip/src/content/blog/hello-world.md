---
title: "Launching Cavazos Analytics"
description: "Why we built a lean, investigative analytics firm and how we work."
date: 2025-08-27
cover: "/og-default.jpg"
tags: ["firm", "intro"]
---
Welcome to the blog. Short, high‑signal posts coming soon.
